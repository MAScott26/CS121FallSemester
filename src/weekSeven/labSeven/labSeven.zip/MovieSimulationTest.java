package weekSeven.labSeven;

public class MovieSimulationTest {
    public static void main(String[] args) {
    MovieSimulationClass.run();

    }

}
